var test = require('./operations.js');
test.runner();