# Hometasks
This repo contains applications with different types of inheritance in javascript.
To run the files follow below steps:
- Install node js with npm module
- Install dependencies from package.json
- use command "node *filename*" in command prompt
